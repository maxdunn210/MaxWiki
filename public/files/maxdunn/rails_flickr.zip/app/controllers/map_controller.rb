class MapController < ApplicationController

  layout 'main'
  
  def show
  end
end
